# game_simulator_fixed.py
# 完整的游戏模拟器 - 固定500步，不提前结束
import random
import logic
import constants as c

def _clone(mat):
    """克隆矩阵"""
    return [row[:] for row in mat]

def _apply_special_cell_effect(mat, special_pos):
    """应用特殊格效果，返回是否减半"""
    if special_pos is None:
        return mat, False
    i, j = special_pos
    if mat[i][j] > 2:
        mat[i][j] //= 2
        return mat, True
    return mat, False

def _random_special_pos():
    """随机生成特殊格位置，与puzzle.py一致"""
    center_start = (c.GRID_LEN - 2) // 2  # = 1 (对于4x4)
    center_end = center_start + 2         # = 3
    return (
        random.randint(center_start, center_end - 1),  # 1 或 2
        random.randint(center_start, center_end - 1)   # 1 或 2
    )

class GameSimulator:
    """游戏模拟器 - 固定500步"""
    
    def __init__(self):
        self.special_cell_pos = _random_special_pos()
        self.matrix = None
        self.step_count = 0
        
        # 停留利用率统计（只要在特殊格上就计数）
        self.max_tile_stay_uses = 0
        self.other_tile_stay_uses = 0
        
        # 减半利用率统计（只有被减半才计数）
        self.max_tile_halve_uses = 0
        self.other_tile_halve_uses = 0
        
        # 记录最大数字历史
        self.max_tile_history = []
        
    def restart(self):
        """重新开始游戏"""
        self.special_cell_pos = _random_special_pos()
        self.matrix = logic.new_game(c.GRID_LEN)
        self.step_count = 0
        self.max_tile_stay_uses = 0
        self.other_tile_stay_uses = 0
        self.max_tile_halve_uses = 0
        self.other_tile_halve_uses = 0
        self.max_tile_history = []
        
        # 记录初始最大数字
        self.max_tile_history.append(max(max(row) for row in self.matrix))
        
        return _clone(self.matrix)
    
    def apply_move(self, move_name):
        """
        应用一步移动
        
        Args:
            move_name: 移动方向 ('Up', 'Down', 'Left', 'Right')
            
        Returns:
            dict: 移动结果
        """
        if self.matrix is None:
            self.restart()
        
        # 记录移动前的状态
        max_tile_before = max(max(row) for row in self.matrix)
        i, j = self.special_cell_pos
        special_value_before = self.matrix[i][j]
        
        # 执行移动
        move_func = getattr(logic, move_name.lower())
        next_matrix, moved = move_func(_clone(self.matrix))
        
        if not moved:
            return {
                'moved': False,
                'max_tile_before': max_tile_before,
                'special_value_before': special_value_before
            }
        
        # 应用特殊格效果
        next_matrix, halved = _apply_special_cell_effect(next_matrix, self.special_cell_pos)
        special_value_after = next_matrix[i][j]
        
        # 1. 停留利用率：只要特殊格上有数字就计数
        if special_value_after > 0:  # 特殊格上有数字
            if special_value_before == max_tile_before:
                self.max_tile_stay_uses += 1
            elif special_value_before > 0:  # 确保不是新生成的数字
                self.other_tile_stay_uses += 1
        
        # 2. 减半利用率：只有当数字被减半时才计数
        if halved:
            if special_value_before == max_tile_before:
                self.max_tile_halve_uses += 1
            else:
                self.other_tile_halve_uses += 1
        
        # 添加新数字
        self.matrix = logic.add_two(next_matrix)
        self.step_count += 1
        
        # 记录当前最大数字
        current_max = max(max(row) for row in self.matrix)
        self.max_tile_history.append(current_max)
        
        return {
            'moved': True,
            'current_matrix': _clone(self.matrix),
            'max_tile_before': max_tile_before,
            'special_value_before': special_value_before,
            'special_value_after': special_value_after,
            'special_stay': special_value_after > 0,
            'special_halved': halved,
            'current_max_tile': current_max,
            'step': self.step_count
        }
    
    def get_game_state(self):
        """获取游戏状态"""
        if self.matrix is None:
            return 'not over'
        return logic.game_state(self.matrix)
    
    def get_current_matrix(self):
        """获取当前矩阵"""
        return _clone(self.matrix) if self.matrix is not None else None
    
    def get_special_position(self):
        """获取特殊格位置"""
        return self.special_cell_pos
    
    def get_utilization_stats(self):
        """获取利用率统计"""
        total_steps = self.step_count
        if total_steps == 0:
            return {
                'stay_util_max': 0.0,
                'stay_util_other': 0.0,
                'halve_util_max': 0.0,
                'halve_util_other': 0.0
            }
        
        return {
            'stay_util_max': self.max_tile_stay_uses / total_steps,
            'stay_util_other': self.other_tile_stay_uses / total_steps,
            'halve_util_max': self.max_tile_halve_uses / total_steps,
            'halve_util_other': self.other_tile_halve_uses / total_steps
        }
    
    def simulate_single_game(self, agent, max_steps=500, game_id=1, verbose=True):
        """
        模拟一局完整的游戏（固定步数）
        
        Args:
            agent: AI agent
            max_steps: 固定步数（500步）
            game_id: 游戏ID
            verbose: 是否显示详细信息
            
        Returns:
            dict: 游戏结果
        """
        # 重新开始游戏
        self.restart()
        
        if verbose:
            print(f"游戏 {game_id} [特殊格: {self.special_cell_pos}]: ", end="")
        
        steps = 0
        last_max_tile = 0
        
        # 固定运行500步
        while steps < max_steps:
            current_matrix = self.get_current_matrix()
            
            # 调用agent选择移动
            try:
                move_name = agent.choose_move(current_matrix)
                if move_name is None:
                    # 没有可用移动，但继续尝试（理论上不应该发生）
                    print("X", end="")  # X表示没有可用移动
                    break
            except Exception as e:
                if verbose:
                    print(f"E", end="")  # E表示出错
                break
            
            # 应用移动
            move_result = self.apply_move(move_name)
            
            if not move_result['moved']:
                # 移动失败，但继续尝试
                print("F", end="")  # F表示移动失败
                continue
            
            # 显示特殊格使用情况
            if verbose:
                if move_result['special_halved']:
                    if move_result['special_value_before'] == move_result['max_tile_before']:
                        print("H", end="")  # H表示最大值被减半
                    else:
                        print("h", end="")  # h表示其他值被减半
                elif move_result['special_stay']:
                    print(".", end="")  # .表示停留在特殊格
                else:
                    print(" ", end="")  # 空格表示没有使用特殊格
            
            # 检查最大数字是否增加
            current_max = move_result['current_max_tile']
            if current_max > last_max_tile:
                if verbose:
                    print(f"[{current_max}]", end="")  # 显示增加的最大数字
                last_max_tile = current_max
            
            steps += 1
        
        # 最终结果
        final_matrix = self.get_current_matrix()
        final_max_tile = max(max(row) for row in final_matrix) if final_matrix else 0
        final_state = self.get_game_state()
        util_stats = self.get_utilization_stats()
        
        if verbose:
            print(f" | 最终: {final_max_tile} | 步数: {steps}")
            print(f"  停留利用率: 最大={util_stats['stay_util_max']:.3f}, 其他={util_stats['stay_util_other']:.3f}")
            print(f"  减半利用率: 最大={util_stats['halve_util_max']:.3f}, 其他={util_stats['halve_util_other']:.3f}")
        
        return {
            'game_id': game_id,
            'special_pos': self.special_cell_pos,
            'steps': steps,
            'max_tile': final_max_tile,
            'max_tile_history': self.max_tile_history.copy(),
            'game_state': final_state,
            # 停留利用率
            'max_tile_stay_uses': self.max_tile_stay_uses,
            'other_tile_stay_uses': self.other_tile_stay_uses,
            'stay_util_max': util_stats['stay_util_max'],
            'stay_util_other': util_stats['stay_util_other'],
            # 减半利用率
            'max_tile_halve_uses': self.max_tile_halve_uses,
            'other_tile_halve_uses': self.other_tile_halve_uses,
            'halve_util_max': util_stats['halve_util_max'],
            'halve_util_other': util_stats['halve_util_other'],
            # 性能指标
            'max_tile_peak': max(self.max_tile_history) if self.max_tile_history else 0,
            'stopped_early': steps < max_steps
        }