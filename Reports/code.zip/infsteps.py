# game_simulator_v3.py
# 简化版游戏模拟器 - 目标256，无限步数，自动结束检测
# 去掉特殊格相关统计，每个模型单独生成报告
import random
import logic
import constants as c
import json
import csv
import os

def _clone(mat):
    """克隆矩阵"""
    return [row[:] for row in mat]

def _random_special_pos():
    """随机生成特殊格位置"""
    center_start = (c.GRID_LEN - 2) // 2  # = 1
    center_end = center_start + 2         # = 3
    return (
        random.randint(center_start, center_end - 1),
        random.randint(center_start, center_end - 1)
    )

class GameSimulatorSimple:
    """简化版游戏模拟器 - 只关注核心指标"""
    
    def __init__(self):
        self.special_cell_pos = _random_special_pos()
        self.matrix = None
        self.step_count = 0
        self.max_step_no_change = 500  # 最大数字500步无变化则结束
        
        # 记录最大数字历史
        self.max_tile_history = []
        
        # 记录游戏状态
        self.game_result = None  # 'win', 'lose', 'stuck'
        
        # 记录最大数字无变化步数
        self.steps_without_max_increase = 0
        self.last_max_tile = 0
        
    def restart(self):
        """重新开始游戏"""
        self.special_cell_pos = _random_special_pos()
        self.matrix = logic.new_game(c.GRID_LEN)
        self.step_count = 0
        self.max_tile_history = []
        self.game_result = None
        self.steps_without_max_increase = 0
        self.last_max_tile = 0
        
        # 记录初始最大数字
        initial_max = max(max(row) for row in self.matrix)
        self.max_tile_history.append(initial_max)
        self.last_max_tile = initial_max
        
        return _clone(self.matrix)
    
    def apply_move(self, move_name):
        """
        应用一步移动
        """
        if self.matrix is None:
            self.restart()
        
        # 执行移动
        move_func = getattr(logic, move_name.lower())
        next_matrix, moved = move_func(_clone(self.matrix))
        
        if not moved:
            return {'moved': False}
        
        # 应用特殊格效果（简化处理）
        i, j = self.special_cell_pos
        if next_matrix[i][j] > 2:
            next_matrix[i][j] //= 2
        
        # 添加新数字
        self.matrix = logic.add_two(next_matrix)
        self.step_count += 1
        
        # 记录当前最大数字
        current_max = max(max(row) for row in self.matrix)
        self.max_tile_history.append(current_max)
        
        # 更新最大数字无变化计数器
        if current_max > self.last_max_tile:
            self.steps_without_max_increase = 0
            self.last_max_tile = current_max
        else:
            self.steps_without_max_increase += 1
        
        # 检查游戏状态
        # 修改胜利条件为256
        if current_max >= 256:  # 达到目标256
            self.game_result = 'win'
        elif logic.game_state(self.matrix) == 'lose':
            self.game_result = 'lose'
        elif self.steps_without_max_increase >= self.max_step_no_change:
            self.game_result = 'stuck'  # 卡住
        
        return {
            'moved': True,
            'current_max_tile': current_max,
            'step': self.step_count,
            'game_state': self.game_result or 'not over',
            'is_final': self.game_result is not None
        }
    
    def get_game_state(self):
        """获取游戏状态"""
        if self.matrix is None:
            return 'not over'
        
        # 检查是否已达到目标
        current_max = max(max(row) for row in self.matrix)
        if current_max >= 256:
            return 'win'
        
        # 检查是否卡住
        if self.steps_without_max_increase >= self.max_step_no_change:
            return 'stuck'
        
        # 否则返回logic的原始状态
        return logic.game_state(self.matrix)
    
    def simulate_single_game(self, agent, game_id=1, verbose=True):
        """
        模拟一局完整的游戏（目标256，无限步数）
        """
        # 重新开始游戏
        self.restart()
        
        if verbose:
            print(f"游戏 {game_id:2d}: ", end="")
        
        # 无限步数，直到游戏结束
        while True:
            current_matrix = self.get_current_matrix()
            
            # 调用agent选择移动
            try:
                move_name = agent.choose_move(current_matrix)
                if move_name is None:
                    # 没有可用移动
                    self.game_result = 'lose'
                    if verbose:
                        print("X", end="")
                    break
            except Exception as e:
                if verbose:
                    print(f"E", end="")
                self.game_result = 'error'
                break
            
            # 应用移动
            move_result = self.apply_move(move_name)
            
            if not move_result['moved']:
                # 移动失败
                if verbose:
                    print("F", end="")
                continue
            
            # 显示最大数字增加
            current_max = move_result['current_max_tile']
            if verbose and current_max > max(self.max_tile_history[:-1] or [0]):
                if current_max >= 256:
                    print(f"[{current_max}]", end="")
                elif current_max >= 64:
                    print(f"[{current_max}]", end="")
            
            # 检查游戏是否应该结束
            if move_result.get('is_final', False):
                break
        
        # 获取最终结果
        final_max_tile = max(max(row) for row in self.matrix) if self.matrix else 0
        final_state = self.get_game_state()
        
        # 确定最终状态
        if final_state == 'win':
            result_type = 'win'
            result_symbol = "✓"
        elif final_state == 'stuck':
            result_type = 'stuck'
            result_symbol = "⏹"
        else:
            result_type = 'lose'
            result_symbol = "✗"
        
        if verbose:
            print(f" | {result_symbol} {result_type.upper():5s} | 最终: {final_max_tile:4d} | 步数: {self.step_count:4d}")
        
        return {
            'game_id': game_id,
            'steps': self.step_count,
            'max_tile': final_max_tile,
            'game_result': result_type,
            'max_tile_history': self.max_tile_history.copy(),
            'steps_without_increase': self.steps_without_max_increase,
            'special_pos': self.special_cell_pos
        }
    
    def get_current_matrix(self):
        """获取当前矩阵"""
        return _clone(self.matrix) if self.matrix is not None else None
    
    def get_special_position(self):
        """获取特殊格位置"""
        return self.special_cell_pos


def evaluate_single_model(model_name, agent, num_games=20):
    """
    评估单个模型并生成报告
    """
    print(f"\n{'='*70}")
    print(f"评估 {model_name} 模型")
    print(f"{'='*70}")
    print(f"设置: {num_games}局，目标：达到256")
    print(f"停止条件: 1) 达到256  2) 游戏失败  3) 最大数字500步无变化")
    print(f"{'='*70}")
    
    simulator = GameSimulatorSimple()
    all_results = []
    win_steps = []
    max_tiles = []
    
    for game_id in range(1, num_games + 1):
        result = simulator.simulate_single_game(agent, game_id=game_id, verbose=True)
        all_results.append(result)
        
        if result['game_result'] == 'win':
            win_steps.append(result['steps'])
        
        max_tiles.append(result['max_tile'])
    
    # 统计
    win_count = sum(1 for r in all_results if r['game_result'] == 'win')
    lose_count = sum(1 for r in all_results if r['game_result'] == 'lose')
    stuck_count = sum(1 for r in all_results if r['game_result'] == 'stuck')
    
    win_rate = win_count / num_games * 100
    avg_win_steps = sum(win_steps) / len(win_steps) if win_steps else 0
    avg_steps = sum(r['steps'] for r in all_results) / num_games
    avg_max_tile = sum(max_tiles) / num_games
    
    # 生成详细报告
    report = generate_model_report(model_name, all_results, num_games, 
                                  win_count, lose_count, stuck_count, win_rate,
                                  avg_win_steps, avg_steps, avg_max_tile)
    
    # 保存结果
    save_model_results(model_name, all_results, report, 
                      win_count, lose_count, stuck_count, win_rate,
                      avg_win_steps, avg_steps, avg_max_tile)
    
    return {
        'results': all_results,
        'stats': {
            'win_count': win_count,
            'lose_count': lose_count,
            'stuck_count': stuck_count,
            'win_rate': win_rate,
            'avg_win_steps': avg_win_steps,
            'avg_steps': avg_steps,
            'avg_max_tile': avg_max_tile
        },
        'report': report
    }


def generate_model_report(model_name, results, num_games, win_count, lose_count, 
                         stuck_count, win_rate, avg_win_steps, avg_steps, avg_max_tile):
    """生成单个模型的详细报告"""
    
    report_lines = []
    report_lines.append("="*70)
    report_lines.append(f"2048 GAME PERFORMANCE REPORT - {model_name}")
    report_lines.append("="*70)
    report_lines.append("")
    report_lines.append("📊 总体统计:")
    report_lines.append("-"*40)
    report_lines.append(f"游戏局数: {num_games}")
    report_lines.append(f"胜局数: {win_count} ({win_rate:.1f}%)")
    report_lines.append(f"负局数: {lose_count}")
    report_lines.append(f"卡住局数: {stuck_count}")
    report_lines.append("")
    
    if win_count > 0:
        report_lines.append("⚡ 获胜效率:")
        report_lines.append("-"*40)
        report_lines.append(f"平均获胜步数: {avg_win_steps:.1f} 步")
        report_lines.append(f"最快获胜步数: {min(r['steps'] for r in results if r['game_result'] == 'win'):.0f} 步")
        report_lines.append(f"最慢获胜步数: {max(r['steps'] for r in results if r['game_result'] == 'win'):.0f} 步")
        report_lines.append("")
    
    report_lines.append("🎯 最大数字统计:")
    report_lines.append("-"*40)
    report_lines.append(f"平均最大数字: {avg_max_tile:.1f}")
    report_lines.append(f"最高最大数字: {max(r['max_tile'] for r in results)}")
    report_lines.append(f"最低最大数字: {min(r['max_tile'] for r in results)}")
    report_lines.append("")
    
    report_lines.append("📈 最大数字分布:")
    report_lines.append("-"*40)
    
    # 统计最大数字分布
    max_tile_counter = {}
    for result in results:
        tile = result['max_tile']
        max_tile_counter[tile] = max_tile_counter.get(tile, 0) + 1
    
    for tile in sorted(max_tile_counter.keys(), reverse=True):
        count = max_tile_counter[tile]
        percentage = count / num_games * 100
        report_lines.append(f"{tile:4d}: {count:2d} 局 ({percentage:5.1f}%)")
    
    report_lines.append("")
    
    report_lines.append("⏱️ 步数统计:")
    report_lines.append("-"*40)
    report_lines.append(f"平均总步数: {avg_steps:.1f}")
    report_lines.append(f"最多步数: {max(r['steps'] for r in results)}")
    report_lines.append(f"最少步数: {min(r['steps'] for r in results)}")
    report_lines.append("")
    
    report_lines.append("🔄 游戏结果详情:")
    report_lines.append("-"*40)
    for result in results[:10]:  # 显示前10局详情
        symbol = "✓" if result['game_result'] == 'win' else "✗" if result['game_result'] == 'lose' else "⏹"
        report_lines.append(f"游戏 {result['game_id']:2d}: {symbol} {result['game_result'].upper():5s} | "
                          f"最大: {result['max_tile']:4d} | 步数: {result['steps']:4d}")
    
    if len(results) > 10:
        report_lines.append(f"... 还有 {len(results) - 10} 局未显示")
    
    report_lines.append("")
    report_lines.append("="*70)
    
    return "\n".join(report_lines)


def save_model_results(model_name, results, report, win_count, lose_count, 
                      stuck_count, win_rate, avg_win_steps, avg_steps, avg_max_tile):
    """保存单个模型的结果"""
    
    # 保存文本报告
    report_filename = f"{model_name.lower()}_performance_report.txt"
    with open(report_filename, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f"✓ 报告已保存: {report_filename}")
    
    # 保存详细数据到CSV
    csv_filename = f"{model_name.lower()}_detailed_results.csv"
    with open(csv_filename, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['game_id', 'special_pos', 'steps', 'max_tile', 'game_result', 'steps_without_increase']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for result in results:
            writer.writerow({
                'game_id': result['game_id'],
                'special_pos': str(result['special_pos']),
                'steps': result['steps'],
                'max_tile': result['max_tile'],
                'game_result': result['game_result'],
                'steps_without_increase': result['steps_without_increase']
            })
    print(f"✓ 详细数据已保存: {csv_filename}")
    
    # 保存统计摘要到JSON
    summary = {
        'model_name': model_name,
        'total_games': len(results),
        'win_count': win_count,
        'lose_count': lose_count,
        'stuck_count': stuck_count,
        'win_rate': win_rate,
        'avg_win_steps': avg_win_steps,
        'avg_steps': avg_steps,
        'avg_max_tile': avg_max_tile,
        'max_tile_distribution': {}
    }
    
    # 添加最大数字分布
    max_tile_counter = {}
    for result in results:
        tile = result['max_tile']
        max_tile_counter[tile] = max_tile_counter.get(tile, 0) + 1
    
    summary['max_tile_distribution'] = max_tile_counter
    
    json_filename = f"{model_name.lower()}_summary.json"
    with open(json_filename, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"✓ 统计摘要已保存: {json_filename}")


def compare_all_models():
    """比较所有可用模型"""
    import sys
    sys.path.append('.')
    
    models_to_evaluate = []
    
    # 定义要评估的模型
    models_config = [
        {
            'name': 'Minimax',
            'import_func': lambda: __import__('agent_Minimax').MinimaxAgent,
            'args': {'special_pos': None, 'depth': 3}
        },
        {
            'name': 'Expectimax',
            'import_func': lambda: __import__('agent_Expectimax').ExpectimaxAgent,
            'args': {'special_pos': None, 'depth': 3}
        },
        {
            'name': 'DQN',
            'import_func': lambda: __import__('agent_Qlearning').DQNAgent,
            'args': {
                'special_pos': None,
                'auto_detect_special': True,
                'state_size': 18,
                'action_size': 4,
                'hidden_size': 256,
                'learning_rate': 0.001,
                'gamma': 0.99,
                'epsilon_start': 0.01,
                'epsilon_end': 0.01,
                'epsilon_decay': 1.0
            },
            'load_model': 'dqn_2048_model.pth'
        },
        {
            'name': 'Actor-Critic',
            'import_func': lambda: __import__('agent_ActorCritic').ActorCriticAgent,
            'args': {
                'special_pos': None,
                'auto_detect_special': True,
                'learning_rate_actor': 0.001,
                'learning_rate_critic': 0.001,
                'gamma': 0.99
            },
            'load_model': 'actor_critic_2048_model.pth'
        }
    ]
    
    all_results = {}
    
    print("="*70)
    print("2048游戏模型全面评估")
    print("目标：256 | 无限步数 | 自动检测卡住")
    print("="*70)
    
    for config in models_config:
        model_name = config['name']
        print(f"\n📋 准备评估 {model_name}...")
        
        try:
            # 导入模型类
            agent_class = config['import_func']()
            
            # 创建agent实例
            agent = agent_class(**config['args'])
            
            # 加载预训练模型（如果指定）
            if 'load_model' in config and hasattr(agent, 'load'):
                try:
                    agent.load(config['load_model'])
                    print(f"  已加载预训练模型: {config['load_model']}")
                except Exception as e:
                    print(f"  警告: 加载模型失败 - {e}")
            
            # 评估模型
            result = evaluate_single_model(model_name, agent, num_games=20)
            all_results[model_name] = result
            
            # 显示简要结果
            stats = result['stats']
            print(f"\n  {model_name} 简要结果:")
            print(f"    胜率: {stats['win_rate']:.1f}% ({stats['win_count']}/20)")
            if stats['win_count'] > 0:
                print(f"    获胜平均步数: {stats['avg_win_steps']:.1f}")
            print(f"    平均最大数字: {stats['avg_max_tile']:.1f}")
            
        except ImportError:
            print(f"  ❌ {model_name} 不可用，跳过")
        except Exception as e:
            print(f"  ❌ 评估 {model_name} 时出错: {e}")
    
    # 生成对比报告
    if all_results:
        generate_comparison_report(all_results)
    
    return all_results


def generate_comparison_report(all_results):
    """生成所有模型的对比报告"""
    
    comparison_lines = []
    comparison_lines.append("="*70)
    comparison_lines.append("2048 GAME MODELS COMPARISON REPORT")
    comparison_lines.append("="*70)
    comparison_lines.append("")
    comparison_lines.append("📊 总体性能排名:")
    comparison_lines.append("-"*40)
    
    # 按胜率排名
    ranked_models = sorted(
        all_results.items(), 
        key=lambda x: (x[1]['stats']['win_rate'], -x[1]['stats']['avg_win_steps']), 
        reverse=True
    )
    
    for rank, (model_name, data) in enumerate(ranked_models, 1):
        stats = data['stats']
        emoji = "🥇" if rank == 1 else "🥈" if rank == 2 else "🥉" if rank == 3 else "🎯"
        win_rate_str = f"{stats['win_rate']:5.1f}%"
        win_steps_str = f"{stats['avg_win_steps']:6.1f}" if stats['win_count'] > 0 else "N/A"
        
        comparison_lines.append(f"{emoji} {model_name:15s} | 胜率: {win_rate_str} | "
                              f"获胜步数: {win_steps_str} | 平均最大: {stats['avg_max_tile']:6.1f}")
    
    comparison_lines.append("")
    comparison_lines.append("📈 详细对比表格:")
    comparison_lines.append("-"*70)
    comparison_lines.append(f"{'模型':15s} {'胜/总':8s} {'胜率':8s} {'获胜步数':10s} {'平均最大':10s} {'平均步数':10s}")
    comparison_lines.append("-"*70)
    
    for model_name, data in all_results.items():
        stats = data['stats']
        win_total = f"{stats['win_count']}/20"
        win_rate = f"{stats['win_rate']:.1f}%"
        win_steps = f"{stats['avg_win_steps']:.1f}" if stats['win_count'] > 0 else "N/A"
        avg_max = f"{stats['avg_max_tile']:.1f}"
        avg_steps = f"{stats['avg_steps']:.1f}"
        
        comparison_lines.append(f"{model_name:15s} {win_total:8s} {win_rate:8s} "
                              f"{win_steps:>10s} {avg_max:>10s} {avg_steps:>10s}")
    
    comparison_lines.append("")
    comparison_lines.append("💡 分析总结:")
    comparison_lines.append("-"*40)
    
    # 找出最佳模型
    best_model = ranked_models[0][0] if ranked_models else None
    if best_model:
        best_stats = all_results[best_model]['stats']
        comparison_lines.append(f"1. 最佳模型: {best_model} (胜率: {best_stats['win_rate']:.1f}%)")
        
        # 效率分析
        efficient_models = []
        for model_name, data in all_results.items():
            stats = data['stats']
            if stats['win_count'] > 0 and stats['avg_win_steps'] < 400:
                efficient_models.append((model_name, stats['avg_win_steps']))
        
        if efficient_models:
            efficient_models.sort(key=lambda x: x[1])
            comparison_lines.append(f"2. 最有效率: {efficient_models[0][0]} (平均{int(efficient_models[0][1])}步获胜)")
        
        # 稳定性分析
        stable_models = [m for m, d in all_results.items() 
                        if d['stats']['stuck_count'] == 0 and d['stats']['win_count'] > 0]
        if stable_models:
            comparison_lines.append(f"3. 最稳定: {', '.join(stable_models)} (从未卡住)")
    
    comparison_lines.append("")
    comparison_lines.append("📁 生成的文件:")
    comparison_lines.append("-"*40)
    for model_name in all_results.keys():
        comparison_lines.append(f"  • {model_name.lower()}_performance_report.txt")
        comparison_lines.append(f"  • {model_name.lower()}_detailed_results.csv")
        comparison_lines.append(f"  • {model_name.lower()}_summary.json")
    
    comparison_lines.append("")
    comparison_lines.append("="*70)
    
    # 保存对比报告
    comparison_report = "\n".join(comparison_lines)
    with open('models_comparison_report.txt', 'w', encoding='utf-8') as f:
        f.write(comparison_report)
    
    print(f"\n✓ 对比报告已保存: models_comparison_report.txt")
    print(comparison_report)


# 单独运行每个模型的函数
def run_minimax_evaluation():
    """单独运行Minimax评估"""
    from agent_Minimax import MinimaxAgent
    agent = MinimaxAgent(special_pos=None, depth=3)
    return evaluate_single_model("Minimax", agent)

def run_expectimax_evaluation():
    """单独运行Expectimax评估"""
    from agent_Expectimax import ExpectimaxAgent
    agent = ExpectimaxAgent(special_pos=None, depth=3)
    return evaluate_single_model("Expectimax", agent)

def run_dqn_evaluation():
    """单独运行DQN评估"""
    from agent_Qlearning import DQNAgent
    agent = DQNAgent(
        special_pos=None,
        auto_detect_special=True,
        state_size=18,
        action_size=4,
        hidden_size=256,
        learning_rate=0.001,
        gamma=0.99,
        epsilon_start=0.01,
        epsilon_end=0.01,
        epsilon_decay=1.0
    )
    try:
        agent.load("dqn_2048_model.pth")
        print("✓ DQN预训练模型加载成功")
    except:
        print("⚠️ DQN使用未训练模型")
    
    return evaluate_single_model("DQN", agent)

def run_actor_critic_evaluation():
    """单独运行Actor-Critic评估"""
    from agent_ActorCritic import ActorCriticAgent
    agent = ActorCriticAgent(
        special_pos=None,
        auto_detect_special=True,
        learning_rate_actor=0.001,
        learning_rate_critic=0.001,
        gamma=0.99
    )
    try:
        agent.load("actor_critic_2048_model.pth")
        print("✓ Actor-Critic预训练模型加载成功")
    except:
        print("⚠️ Actor-Critic使用未训练模型")
    
    return evaluate_single_model("Actor-Critic", agent)


if __name__ == "__main__":
    # 使用方式1: 运行所有模型比较
    print("选择运行模式:")
    print("1. 比较所有模型")
    print("2. 单独运行Minimax")
    print("3. 单独运行Expectimax")
    print("4. 单独运行DQN")
    print("5. 单独运行Actor-Critic")
    
    choice = input("\n请输入选择 (1-5): ").strip()
    
    if choice == "1":
        compare_all_models()
    elif choice == "2":
        run_minimax_evaluation()
    elif choice == "3":
        run_expectimax_evaluation()
    elif choice == "4":
        run_dqn_evaluation()
    elif choice == "5":
        run_actor_critic_evaluation()
    else:
        print("无效选择，运行所有模型比较")
        compare_all_models()