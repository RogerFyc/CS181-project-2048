# evaluate_agent_fixed.py
# 完整的评估脚本 - 固定500步，生成分析报告
import json
import csv
import time
import numpy as np
import math
from collections import defaultdict, Counter
import os
import sys

sys.path.append('.')

from game_simulator import GameSimulator

def calculate_correlation(x_values, y_values):
    """计算相关性系数"""
    if len(x_values) < 2:
        return 0.0
    
    n = len(x_values)
    x_mean = np.mean(x_values)
    y_mean = np.mean(y_values)
    
    numerator = sum((x - x_mean) * (y - y_mean) for x, y in zip(x_values, y_values))
    denominator_x = sum((x - x_mean) ** 2 for x in x_values)
    denominator_y = sum((y - y_mean) ** 2 for y in y_values)
    
    if denominator_x > 0 and denominator_y > 0:
        correlation = numerator / math.sqrt(denominator_x * denominator_y)
    else:
        correlation = 0.0
    
    return correlation

def linear_regression(x_values, y_values):
    """线性回归"""
    if len(x_values) < 2:
        return 0.0, 0.0, 0.0
    
    n = len(x_values)
    x_mean = np.mean(x_values)
    y_mean = np.mean(y_values)
    
    numerator = sum((x - x_mean) * (y - y_mean) for x, y in zip(x_values, y_values))
    denominator = sum((x - x_mean) ** 2 for x in x_values)
    
    if denominator > 0:
        slope = numerator / denominator
        intercept = y_mean - slope * x_mean
        
        # 计算R-squared
        ss_res = sum((y - (slope * x + intercept)) ** 2 for x, y in zip(x_values, y_values))
        ss_tot = sum((y - y_mean) ** 2 for y in y_values)
        r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
    else:
        slope = 0.0
        intercept = 0.0
        r_squared = 0.0
    
    return slope, intercept, r_squared

def evaluate_agent(agent_class, agent_name, num_games=20, max_steps=500, 
                  load_model=False, model_path=None, **agent_args):
    """
    评估Agent - 固定500步，支持加载预训练模型
    
    Args:
        agent_class: Agent类
        agent_name: Agent名称
        num_games: 游戏局数
        max_steps: 每局固定步数
        load_model: 是否加载预训练模型
        model_path: 模型文件路径
        **agent_args: 传递给Agent构造函数的参数
    """
    print(f"\n{'='*70}")
    print(f"评估 {agent_name} Agent - 固定{max_steps}步")
    print(f"{'='*70}")
    
    # 自动选择模型路径（如果未指定）
    if model_path is None and load_model:
        agent_lower = agent_name.lower()
        if agent_lower == "dqn":
            model_path = "dqn_2048_model.pth"
        elif "actor" in agent_lower or "critic" in agent_lower:
            model_path = "actor_critic_2048_model.pth"
    
    # 创建agent
    try:
        agent = agent_class(special_pos=None, **agent_args)
        print(f"✓ {agent_name} Agent创建成功")
        
        # 加载预训练模型
        if load_model and model_path:
            if hasattr(agent, 'load'):
                try:
                    agent.load(model_path)
                    print(f"✓ 已加载预训练模型: {model_path}")
                except Exception as e:
                    print(f"⚠️  加载模型失败: {e}")
                    print("  将使用未训练的模型进行评估")
            else:
                print(f"⚠️  {agent_name} Agent没有load方法，跳过模型加载")
    except Exception as e:
        print(f"✗ 创建agent失败: {e}")
        return None, None
    
    # 开始评估
    results = []
    start_time = time.time()
    
    print(f"\n开始评估...")
    print("特殊格使用标记: H=最大值减半, h=其他值减半, .=停留在特殊格, [数字]=最大数字增加")
    
    for game_idx in range(num_games):
        verbose = (game_idx + 1) % 1 == 0
        if verbose:
            print(f"\n游戏 {game_idx + 1}: ", end="")
        
        # 模拟游戏
        simulator = GameSimulator()
        result = simulator.simulate_single_game(
            agent=agent,
            max_steps=max_steps,
            game_id=game_idx + 1,
            verbose=verbose
        )
        
        results.append(result)
        
        if not verbose:
            print(".", end="", flush=True)
    
    elapsed_time = time.time() - start_time
    print(f"\n\n评估完成！总耗时: {elapsed_time:.2f}秒")
    
    # 生成分析报告
    report = generate_analysis_report(agent_name, results, elapsed_time, max_steps)
    print(report)
    
    # 保存报告和数据
    save_results(agent_name, results, report, max_steps)
    
    return results, report

def generate_analysis_report(agent_name, results, elapsed_time, max_steps):
    """生成分析报告"""
    
    # 准备数据
    max_tiles = [r['max_tile'] for r in results]
    steps_list = [r['steps'] for r in results]
    
    # 停留利用率（使用这种计算方式）
    stay_util_other = [r['stay_util_other'] for r in results]  # special_other_util
    stay_util_max = [r['stay_util_max'] for r in results]      # special_max_util
    
    report_lines = []
    report_lines.append("="*70)
    report_lines.append(f"2048 GAME DATA ANALYSIS REPORT ({agent_name} Agent - 定{max_steps}步)")
    report_lines.append("="*70)
    report_lines.append("")
    
    # 1. 最大数字出现次数
    report_lines.append("1. MAX TILE OCCURRENCES:")
    report_lines.append("-"*40)
    
    max_tile_counter = Counter(max_tiles)
    total_games = len(results)
    
    # 按数字大小排序（从大到小）
    sorted_tiles = sorted(max_tile_counter.items(), key=lambda x: int(x[0]), reverse=True)
    
    for tile, count in sorted_tiles:
        percentage = count / total_games * 100
        report_lines.append(f"Max Tile {tile}: {count} times ({percentage:.1f}%)")
    
    report_lines.append("")
    report_lines.append(f"Total games: {total_games}")
    report_lines.append("")
    
    # 2. 平均值统计
    report_lines.append("2. AVERAGE VALUES:")
    report_lines.append("-"*40)
    
    # special_other_util
    if stay_util_other:
        report_lines.append("special_other_util: 除最大值外其余值利用特殊格的概率")
        report_lines.append(f"  Average: {np.mean(stay_util_other):.4f}")
        report_lines.append(f"  Min: {np.min(stay_util_other):.4f}")
        report_lines.append(f"  Max: {np.max(stay_util_other):.4f}")
        report_lines.append(f"  Count: {len(stay_util_other)}")
        report_lines.append("")
    
    # max_tile
    if max_tiles:
        report_lines.append("max_tile:")
        report_lines.append(f"  Average: {np.mean(max_tiles):.4f}")
        report_lines.append(f"  Min: {np.min(max_tiles):.4f}")
        report_lines.append(f"  Max: {np.max(max_tiles):.4f}")
        report_lines.append(f"  Count: {len(max_tiles)}")
        report_lines.append("")
    
    # special_max_util
    if stay_util_max:
        report_lines.append("special_max_util: 最大值利用特殊格的概率")
        report_lines.append(f"  Average: {np.mean(stay_util_max):.4f}")
        report_lines.append(f"  Min: {np.min(stay_util_max):.4f}")
        report_lines.append(f"  Max: {np.max(stay_util_max):.4f}")
        report_lines.append(f"  Count: {len(stay_util_max)}")
        report_lines.append("")
    
    # 3. 相关性分析
    report_lines.append("3. UTILITY VS MAX TILE TREND: special_other_util与最大值")
    report_lines.append("-"*40)
    
    if len(max_tiles) >= 2 and len(stay_util_other) >= 2:
        # 计算相关性
        correlation = calculate_correlation(max_tiles, stay_util_other)
        
        # 线性回归
        slope, intercept, r_squared = linear_regression(max_tiles, stay_util_other)
        
        report_lines.append(f"Correlation: {correlation:.3f}")
        report_lines.append(f"Data points: {len(max_tiles)}")
        report_lines.append(f"Trend line: y = {slope:.4f}x + {intercept:.4f}")
        report_lines.append(f"R-squared: {r_squared:.4f}")
    else:
        report_lines.append("Not enough data for correlation analysis")
    
    report_lines.append("")
    
    # 4. 按最大数字分组的利用率统计
    report_lines.append("4. UTILITY BY MAX TILE: special_other_util")
    report_lines.append("-"*40)
    report_lines.append("")
    
    # 按最大数字分组
    tile_groups = defaultdict(list)
    for tile, util in zip(max_tiles, stay_util_other):
        tile_groups[tile].append(util)
    
    # 按最大数字排序（从大到小）
    for tile in sorted(tile_groups.keys(), key=lambda x: int(x), reverse=True):
        utils = tile_groups[tile]
        count = len(utils)
        
        if count > 0:
            mean_util = np.mean(utils)
            median_util = np.median(utils)
            min_util = np.min(utils)
            max_util = np.max(utils)
            std_dev = np.std(utils) if count > 1 else 0
            
            report_lines.append(f"Max Tile {tile}:")
            report_lines.append(f"  Games: {count}")
            report_lines.append(f"  Mean Special: {mean_util:.4f}")
            report_lines.append(f"  Median Special: {median_util:.4f}")
            report_lines.append(f"  Range: {min_util:.4f} - {max_util:.4f}")
            report_lines.append(f"  Std Dev: {std_dev:.4f}")
            report_lines.append("")
    
    report_lines.append("")
    report_lines.append("="*70)
    
    return "\n".join(report_lines)

def save_results(agent_name, results, report, max_steps):
    """保存结果到文件"""
    
    # 保存文本报告
    report_filename = f"{agent_name.lower()}_analysis_report.txt"
    with open(report_filename, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f"分析报告已保存到: {report_filename}")
    
    # 保存详细数据到CSV
    csv_filename = f"{agent_name.lower()}_detailed_data.csv"
    with open(csv_filename, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = [
            'game_id', 'special_pos', 'steps', 'max_tile', 'game_state',
            # 停留利用率
            'max_tile_stay_uses', 'other_tile_stay_uses',
            'stay_util_max', 'stay_util_other',
            # 减半利用率
            'max_tile_halve_uses', 'other_tile_halve_uses',
            'halve_util_max', 'halve_util_other',
            'max_tile_peak', 'stopped_early'
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for result in results:
            writer.writerow({
                'game_id': result['game_id'],
                'special_pos': str(result['special_pos']),
                'steps': result['steps'],
                'max_tile': result['max_tile'],
                'game_state': result['game_state'],
                # 停留利用率
                'max_tile_stay_uses': result['max_tile_stay_uses'],
                'other_tile_stay_uses': result['other_tile_stay_uses'],
                'stay_util_max': result['stay_util_max'],
                'stay_util_other': result['stay_util_other'],
                # 减半利用率
                'max_tile_halve_uses': result['max_tile_halve_uses'],
                'other_tile_halve_uses': result['other_tile_halve_uses'],
                'halve_util_max': result['halve_util_max'],
                'halve_util_other': result['halve_util_other'],
                'max_tile_peak': result['max_tile_peak'],
                'stopped_early': result['stopped_early']
            })
    
    print(f"详细数据已保存到: {csv_filename}")
    
    # 保存JSON格式数据（供你的分析脚本使用）
    json_data = []
    for result in results:
        json_data.append({
            'max_tile': result['max_tile'],
            'special_other_util': result['stay_util_other'],  # 使用停留利用率
            'special_max_util': result['stay_util_max'],      # 使用停留利用率
            'steps': result['steps'],
            'game_state': result['game_state'],
            'special_pos': result['special_pos']
        })
    
    json_filename = f"{agent_name.lower()}_game_data.json"
    with open(json_filename, 'w', encoding='utf-8') as f:
        json.dump(json_data, f, indent=2, ensure_ascii=False)
    
    print(f"JSON数据已保存到: {json_filename}")