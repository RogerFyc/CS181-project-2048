# evaluate_minimax.py
import sys
sys.path.append('.')

from evaluate import evaluate_agent
from agent_Minimax import MinimaxAgent

if __name__ == "__main__":
    print("="*70)
    print("Minimax Agent 评估 - 固定500步")
    print("="*70)
    
    results, report = evaluate_agent(
        agent_class=MinimaxAgent,
        agent_name="Minimax",
        num_games=20,
        max_steps=500,
        depth=3,
        max_min_branches=6
    )