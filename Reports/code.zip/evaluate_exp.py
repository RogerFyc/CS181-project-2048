# evaluate_expectimax.py
import sys
sys.path.append('.')

from evaluate import evaluate_agent
from agent_Expectimax import ExpectimaxAgent

if __name__ == "__main__":
    print("="*70)
    print("Expectimax Agent 评估 - 固定500步")
    print("="*70)
    
    results, report = evaluate_agent(
        agent_class=ExpectimaxAgent,
        agent_name="Expectimax",
        num_games=20,
        max_steps=500,
        depth=3,
        max_chance_branches=6,
        sample_chance=False
    )