# evaluate_actor_critic.py
import sys
sys.path.append('.')

try:
    from agent_ActorCritic import ActorCriticAgent
    ACTOR_CRITIC_AVAILABLE = True
except ImportError:
    print("错误: Actor-Critic Agent不可用，请安装PyTorch")
    ACTOR_CRITIC_AVAILABLE = False

from evaluate import evaluate_agent
# evaluate_ac.py 修改后：

if __name__ == "__main__":
    results, report = evaluate_agent(
        agent_class=ActorCriticAgent,
        agent_name="ActorCritic_Pretrained",
        num_games=20,
        max_steps=500,
        state_size=18,
        action_size=4,
        hidden_size=256,
        learning_rate_actor=0.001,
        learning_rate_critic=0.001,
        gamma=0.99,
        load_model=True,
        model_path="actor_critic_2048_model.pth"
    )