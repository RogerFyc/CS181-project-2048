# evaluate_dqn.py
import sys
sys.path.append('.')

try:
    from agent_Qlearning import DQNAgent
    DQN_AVAILABLE = True
except ImportError:
    print("错误: DQN Agent不可用，请安装PyTorch")
    DQN_AVAILABLE = False

from evaluate import evaluate_agent

if __name__ == "__main__":
    if not DQN_AVAILABLE:
        print("DQN Agent不可用，跳过评估")
        exit(1)
    
    print("="*70)
    print("DQN Agent 评估 - 固定500步")
    print("="*70)
    
    results, report = evaluate_agent(
        agent_class=DQNAgent,
        agent_name="DQN_Pretrained",  # 添加_Pretrained以示区别
        num_games=20,
        max_steps=500,
        state_size=18,
        action_size=4,
        hidden_size=256,
        learning_rate=0.001,
        gamma=0.99,
        load_model=True,              # 关键参数：指示加载模型
        model_path="dqn_2048_model.pth"  # 关键参数：指定模型文件
    )